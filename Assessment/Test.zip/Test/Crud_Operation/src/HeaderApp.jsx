import React from 'react'
import { Container } from 'react-bootstrap'
export default function HeaderApp() {
  return (
    <div>
    <Container fluid className='bg-secondary p-4'>

        <h3 className='text-white'>Task Manager</h3>
    </Container>
      
    </div>
  )
}
